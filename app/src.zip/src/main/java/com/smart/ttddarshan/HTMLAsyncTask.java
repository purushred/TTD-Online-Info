package com.smart.ttddarshan;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.ArrayAdapter;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created by purushoy on 3/30/2015.
 */
public class HTMLAsyncTask extends AsyncTask<Void, Void, Void> {
    private final MainActivity mainActivity;
    private String htmlText;
    public static Map<String, String> datesMap = new TreeMap<>();
    public static Map<String, String> sevasMap = new TreeMap<>();

    public HTMLAsyncTask(MainActivity mainActivity) {
        this.mainActivity = mainActivity;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    private Map<String, String> getComboValues(Document document, String comboId) {

        Elements dropdown = document.select(comboId);
        Elements options = dropdown.select("option");
        Map<String, String> map = new TreeMap<>();
        for (Element element : options) {
            map.put(element.text(), element.attr("value"));
        }
        return map;
    }

    @Override
    protected Void doInBackground(Void... params) {
        try {
            Document document = Jsoup.connect(AppUtils.SITE_URL).get();

            datesMap = getComboValues(document, "#cmbDate");
            sevasMap = getComboValues(document, "#cmbSeva");

            AppUtils.STATE_STR = document.select("#__VIEWSTATE").attr("value");
            AppUtils.VALIDATION_STR = document.select("#__EVENTVALIDATION").attr("value");

            htmlText = "<html><head>" + AppUtils.CSS_STYLE + "</head><body>" + document.select("#Calendar1").outerHtml() + "</body><html>";
        } catch (IOException e) {
            Log.e("Exception", e.getMessage());
        }
        return null;
    }

    @Override
    protected void onPostExecute(Void result) {
        mainActivity.webView.getSettings().setJavaScriptEnabled(true);
        mainActivity.webView.loadDataWithBaseURL(null, htmlText, "text/html", "utf-8", null);

        ArrayAdapter datesAdapter = new ArrayAdapter(mainActivity, android.R.layout.simple_spinner_item,
                new ArrayList<String>(datesMap.keySet()));
        datesAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mainActivity.monthSpinner.setAdapter(datesAdapter);

        ArrayAdapter sevaAdapter = new ArrayAdapter(mainActivity, android.R.layout.simple_spinner_item,
                new ArrayList<String>(sevasMap.keySet()));
        sevaAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mainActivity.sevaSpinner.setAdapter(sevaAdapter);

        mainActivity.sevaSpinner.setOnItemSelectedListener(mainActivity);
        mainActivity.monthSpinner.setOnItemSelectedListener(mainActivity);
    }
}