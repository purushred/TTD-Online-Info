package com.smart.ttddarshan;

/**
 * Created by purushoy on 3/30/2015.
 */
public class AppUtils {

    public static String SITE_URL = "https://www.ttdsevaonline.com/eSeva/AvailabilityChart.aspx";
    public static String STATE_STR;
    public static String VALIDATION_STR;
    public static String CSS_STYLE = "<style type=\"text/css\">" +
            ".r{ color: #ffffff;  background-color: #f39c12;}" +
            ".g{ color: #ffffff;  background-color: #18bc9c;}" +
            ".b{ color: #ffffff;  background-color: #3498db;}" +
            "</style>";
}
